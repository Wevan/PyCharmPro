CREATE VIEW tmp_id AS
  SELECT `dev`.`uek_privilege_menu`.`id` AS `id`
  FROM `dev`.`uek_privilege_menu`
  WHERE ((NOT (`dev`.`uek_privilege_menu`.`parent_id` IN (SELECT `dev`.`uek_privilege_menu`.`id`
                                                          FROM `dev`.`uek_privilege_menu`
                                                          WHERE `dev`.`uek_privilege_menu`.`parent_id` IN
                                                                (SELECT `dev`.`uek_privilege_menu`.`id`
                                                                 FROM `dev`.`uek_privilege_menu`
                                                                 WHERE ((`dev`.`uek_privilege_menu`.`name` IN
                                                                         ('系统管理', '人力行政', '教务管理', '就业服务')) AND isnull(
                                                                            `dev`.`uek_privilege_menu`.`parent_id`))))))
         AND (NOT (`dev`.`uek_privilege_menu`.`parent_id` IN (SELECT `dev`.`uek_privilege_menu`.`id`
                                                              FROM `dev`.`uek_privilege_menu`
                                                              WHERE ((`dev`.`uek_privilege_menu`.`name` IN
                                                                      ('系统管理', '人力行政', '教务管理', '就业服务')) AND isnull(
                                                                         `dev`.`uek_privilege_menu`.`parent_id`))))));
